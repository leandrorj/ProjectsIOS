//
//  ViewController.h
//  PrimeiroProjeto
//
//  Created by Treinamento on 29/07/17.
//  Copyright © 2017 Treinamento. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *minhaLabel;
@property (weak, nonatomic) IBOutlet UIButton *botaoGrande;


@end

