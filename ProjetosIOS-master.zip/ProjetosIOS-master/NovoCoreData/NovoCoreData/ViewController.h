//
//  ViewController.h
//  NovoCoreData
//
//  Created by Treinamento on 19/08/17.
//  Copyright © 2017 Treinamento. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *textMarca;

@property (weak, nonatomic) IBOutlet UITextField *textNome;

@property (weak, nonatomic) IBOutlet UITextField *textQuantidade;



@end

