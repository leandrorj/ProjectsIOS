//
//  CustomTableViewCell.m
//  ProjetoTeste
//
//  Created by Treinamento on 05/08/17.
//  Copyright © 2017 Roadmaps. All rights reserved.
//

#import "CustomTableViewCell.h"

@implementation CustomTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
