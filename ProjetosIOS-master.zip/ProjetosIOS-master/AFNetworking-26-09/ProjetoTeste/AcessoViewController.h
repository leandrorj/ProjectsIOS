//
//  AcessoViewController.h
//  ProjetoTeste
//
//  Created by Treinamento on 26/08/17.
//  Copyright © 2017 Roadmaps. All rights reserved.
//

#import "ViewController.h"

@interface AcessoViewController : ViewController

@property (strong, nonatomic) IBOutlet UITextField *nomeUsuario;

@property (strong, nonatomic) IBOutlet UITextField *senhaUsuario;

@end
