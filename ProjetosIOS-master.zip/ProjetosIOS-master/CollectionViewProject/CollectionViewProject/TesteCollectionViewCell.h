//
//  TesteCollectionViewCell.h
//  CollectionViewProject
//
//  Created by Treinamento on 12/08/17.
//  Copyright © 2017 Treinamento. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TesteCollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UILabel *labelLabel;

@end
