//
//  TesteCollectionViewCell.m
//  CollectionViewProject
//
//  Created by Treinamento on 12/08/17.
//  Copyright © 2017 Treinamento. All rights reserved.
//

#import "TesteCollectionViewCell.h"

@implementation TesteCollectionViewCell

@end
